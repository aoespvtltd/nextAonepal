import React from 'react'

function MobileFooter() {
  return (
    <div>MobileFooter</div>
  )
}

export default MobileFooter